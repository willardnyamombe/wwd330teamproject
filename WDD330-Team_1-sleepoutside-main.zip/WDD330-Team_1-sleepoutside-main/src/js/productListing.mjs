import ProductData from "./ProductData.mjs";
import productListing from "./productList.mjs";
import { loadHeaderFooter } from "./utils.mjs";

const productListUl = document.querySelector(".product-list");
// console.log(productListUl);
const dataSource = new ProductData("tents");
const productList = new productListing("tents", dataSource, productListUl);
productList.init();